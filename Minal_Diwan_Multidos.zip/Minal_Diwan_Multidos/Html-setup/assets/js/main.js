// project Carousel JS
jQuery('.project-carousel').owlCarousel({
    loop:true,
    items:3,
    dots:true,
    nav:false,
    margin:30,
    autoplay: true,
    animateIn: 'fadeIn',
    animateOut: 'fadeOut',
    smartSpeed: 700,
    autoplayTimeout:4000,
    autoplayHoverPause:true,
    responsive:{
        0:{
            items:1
        },
        767:{
            items:2
        },
        1000:{
            items:3
        }
    }
})
// team Carousel JS
jQuery('.team-carousel').owlCarousel({
    loop:true,
    items:3,
    dots:true,
    nav:false,
    margin:30,
    autoplay: true,
    smartSpeed: 1000,
    autoplayTimeout:4000,
    autoplayHoverPause:true,
    responsive:{
        0:{
            items:1
        },
        767:{
            items:2
        },
        1000:{
            items:3
        }
    }
})
// testimonial Carousel JS
jQuery('.testimonial-carousel').owlCarousel({
    loop:false,
    items:1,
    dots:true,
    nav:false,
    margin:0,
    autoplay: true,
    smartSpeed: 1000,
    autoplayTimeout:3000,
    autoplayHoverPause:true,
    responsive:{
         0:{
            items:1
        },
        767:{
            items:1
        },
        1000:{
            items:1
        }
    }
})
//sticky navbar
jQuery(window).on("scroll",function(a){
    190<jQuery(window).scrollTop()?jQuery("#main-header").addClass("affix"):jQuery("#main-header").removeClass("affix")
});

// Counter js //
jQuery(window).scroll(startCounter);
function startCounter() {
  if(jQuery('.counter-inner').length > 0)
  {
    var hT = jQuery('.counter-inner').offset().top,
        hH = jQuery('.counter-inner').outerHeight(),
        wH = jQuery(window).height();
    if (jQuery(window).scrollTop() > hT+hH-wH) {
        jQuery(window).off("scroll", startCounter);
        jQuery('.counter-number').each(function () {
            var $this = jQuery(this);
            jQuery({ Counter: 0 }).animate({ Counter: $this.text() }, {
                duration: 6000,
                easing: 'swing',
                step: function () {
                  $this.text(Math.ceil(this.Counter) + '');
                }
            });
        });
    }
  }
}

// wowjs animation library
jQuery(document).ready(function($){wow = new WOW({boxClass:'wow', animateClass: 'animated',offset: 0, mobile: true,live:true});wow.init();});

// Scroll top js 
var scrollTrigger,backToTop;jQuery("#scroll-to-top").length&&(scrollTrigger=100,(backToTop=function(){var o=jQuery(window).scrollTop();scrollTrigger<o?jQuery("#scroll-to-top").addClass("show"):jQuery("#scroll-to-top").removeClass("show")})(),jQuery(window).on("scroll",function(){backToTop()}),jQuery("#scroll-to-top").on("click",function(o){o.preventDefault(),jQuery("html,body").animate({scrollTop:0},700)}));